package ch.epfl.javelo;

public final class Math2 {
    private Math2 (){

    }

    public static int ceilDiv(int x, int y){
        //Preconditions.checkArgument();
        return 0;
    }
    //public static double interpolate(double y0, double y1, double x){


}
