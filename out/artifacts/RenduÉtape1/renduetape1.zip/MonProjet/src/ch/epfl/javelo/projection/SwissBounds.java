package ch.epfl.javelo.projection;

public class SwissBounds {
}
